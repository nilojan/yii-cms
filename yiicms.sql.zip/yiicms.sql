-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 23, 2015 at 12:25 PM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `yiicms`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_articles`
--
-- Creation: Sep 21, 2015 at 08:01 AM
--

CREATE TABLE IF NOT EXISTS `tbl_articles` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `title` varchar(254) NOT NULL,
  `introText` varchar(254) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(254) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  `createDate` datetime NOT NULL,
  `editDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COMMENT='article table for posts';

--
-- RELATIONS FOR TABLE `tbl_articles`:
--

--
-- Dumping data for table `tbl_articles`
--

INSERT INTO `tbl_articles` (`id`, `uid`, `title`, `introText`, `description`, `image`, `status`, `createDate`, `editDate`) VALUES
(1, 1, 'Hello World Post- 1st Post', 'Hello World Post- 1st Post', 'Hello World Post - 1st Post &nbsp;Align the image at the bottom&nbsp;Align the image at the topAlign the image at the topAlign the image at the top&nbsp;The align attribute of &lt;img&gt; is not supported in HTML5. Use CSS instead.For the image to align middle, top, or bottom use the CSS property&nbsp;vertical-align.For the image to align left or right use the CSS property&nbsp;float.&nbsp;The align attribute of &lt;img&gt; is not supported in HTML5. Use CSS instead.For the image to align middle, top, or bottom use the CSS property&nbsp;vertical-align.For the image to align left or right use the CSS property&nbsp;float.&nbsp;Browser SupportAttributealignYesYesYesYesYesThe align attribute is deprecated, but still supported in all major browsers.', 'articl_pic_Chrysanthemum.jpg', 1, '0000-00-00 00:00:00', '2015-09-21 08:00:46'),
(2, 1, 'Second article', 'Second article intro', 'Second article desctiption', 'articl_pic_sushi.jpg', 1, '2015-09-22 11:26:45', '2015-09-22 03:26:45'),
(7, 1, 'final check', 'fgfdg', 'gjsfg', 'articl_pic_must.png', 1, '2015-09-22 11:56:38', '2015-09-22 03:56:38'),
(8, 1, '4th article here go man', '4th article here go man', '4th article here go man&nbsp;4th article here&nbsp;We&#39;re bringing OST (Open Space Technology) closer to the west so that it is easier for people living near to attend! Open Space Facilitator: Steven Koh from IDA Open Space Theme: Skillset and mindset of an Agile team&nbsp; Agenda 7:00pm - Networking ...&nbsp;We&#39;re bringing OST (Open Space Technology) closer to the west so that it is easier for people living near to attend! Open Space Facilitator: Steven Koh from IDA Open Space Theme: Skillset and mindset of an Agile team&nbsp; Agenda 7:00pm - Networking ...&nbsp;go man&nbsp;4th article here go man&nbsp;', 'articl_pic_Penguins.jpg', 1, '2015-09-22 20:50:54', '2015-09-22 12:50:54');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_menu`
--
-- Creation: Sep 21, 2015 at 08:30 AM
--

CREATE TABLE IF NOT EXISTS `tbl_menu` (
  `id` int(11) NOT NULL,
  `Title` varchar(20) NOT NULL,
  `shortText` varchar(99) NOT NULL,
  `page_id` int(11) NOT NULL,
  `level` int(1) NOT NULL DEFAULT '1',
  `parent_id` int(11) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  `createDate` datetime NOT NULL,
  `editDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- RELATIONS FOR TABLE `tbl_menu`:
--   `page_id`
--       `tbl_page` -> `id`
--

--
-- Dumping data for table `tbl_menu`
--

INSERT INTO `tbl_menu` (`id`, `Title`, `shortText`, `page_id`, `level`, `parent_id`, `status`, `createDate`, `editDate`) VALUES
(1, 'Home', 'home', 1, 1, 0, 1, '2015-09-21 04:11:11', '2015-09-21 08:01:21'),
(2, 'About Us', 'about-us', 2, 1, 0, 1, '2015-09-21 06:15:15', '2015-09-21 08:01:24'),
(3, 'Contact us', 'contact-us', 3, 1, 0, 1, '2015-09-21 05:11:11', '2015-09-21 09:46:08'),
(4, 'About us Child', 'about-us-child', 2, 2, 2, 1, '2015-09-21 03:08:11', '2015-09-22 02:34:05'),
(5, 'Contact us Child', 'contact-us-child', 3, 2, 3, 1, '2015-09-22 04:11:11', '2015-09-22 02:34:47'),
(6, 'Home Sub', 'home-sub', 1, 2, 1, 1, '2015-09-22 12:46:40', '2015-09-22 04:46:40'),
(7, 'Articles', 'articles', 6, 1, 0, 1, '2015-09-22 19:51:19', '2015-09-22 11:53:14');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_page`
--
-- Creation: Sep 21, 2015 at 08:01 AM
--

CREATE TABLE IF NOT EXISTS `tbl_page` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `title` varchar(254) NOT NULL,
  `introText` varchar(254) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(120) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  `createDate` datetime NOT NULL,
  `editDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='article table for posts';

--
-- RELATIONS FOR TABLE `tbl_page`:
--

--
-- Dumping data for table `tbl_page`
--

INSERT INTO `tbl_page` (`id`, `uid`, `title`, `introText`, `description`, `image`, `status`, `createDate`, `editDate`) VALUES
(1, 1, 'Home', 'Home', 'Home text , contents all goes here man,Lorem ipsum dolor sit amet, eros principes gubergren vel ut, et sit sale ubique, putent possim viderer te nec. Rebum appetere ad has, erroribus consectetuer ad duo. Id fierent philosophia eum, quot aperiri philosophia cu eum. Ex pro iriure tractatos qualisque, eius congue sea ad. Graeco lo&nbsp;bortis quo at, ad nam eligendi facilisi. Sea sale ceteros in, dico menandri pericula id has. An quod voluptatum cum, vel meis eleifend cu. Vim te quem illum vocent, eu eos detracto albucius, partem putant invenire vis an. Qui cu mentitum suscipit, ut vim ullum quodsi. Et mea iracundia interpretaris, no veniam appareat disputando has. Qui at purto erant oportere, per postea referrentur id. E&nbsp;os ex quem singulis assentior. Error nobis probatus id cum, vis an mutat partem, ex est quem disputando referrentur. Affert causae duo ei. Vix id alii insole&nbsp;ns, te luptatum perpetua vim. Repudiare aliquando concludaturque vel ei, at sit malorum inermis. Nusquam persequeris no eos.', 'page_pic_Tulips.jpg', 1, '2015-09-21 05:11:12', '2015-09-22 07:00:05'),
(2, 1, 'About us', 'About Us', 'About us contents goes here.. here we see all about us contents', '', 1, '2015-09-21 05:00:00', '2015-09-21 11:08:49'),
(3, 1, 'Contact us', 'Contact us', 'Contact us, call us . ping us contents goes here yo', '', 1, '2015-09-21 08:17:13', '2015-09-21 11:09:16'),
(6, 1, 'Articles', 'list of Artilces', 'Articles', '', 1, '2015-09-22 19:51:04', '2015-09-22 11:52:55');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_settings`
--
-- Creation: Sep 23, 2015 at 08:20 AM
--

CREATE TABLE IF NOT EXISTS `tbl_settings` (
  `id` int(11) NOT NULL,
  `param` varchar(99) NOT NULL,
  `val` varchar(99) NOT NULL,
  `createDate` date NOT NULL,
  `editDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- RELATIONS FOR TABLE `tbl_settings`:
--

--
-- Dumping data for table `tbl_settings`
--

INSERT INTO `tbl_settings` (`id`, `param`, `val`, `createDate`, `editDate`) VALUES
(1, 'home_page', '1', '2015-09-22', '2015-09-22 12:09:24'),
(2, 'article_page', '6', '2015-09-22', '2015-09-22 12:10:05'),
(3, 'site_name', 'MUSTERFIRMA', '2015-09-23', '2015-09-23 01:46:39'),
(4, 'slider_on_off', '1', '0000-00-00', '2015-09-23 08:21:02');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_slider`
--
-- Creation: Sep 21, 2015 at 09:18 AM
--

CREATE TABLE IF NOT EXISTS `tbl_slider` (
  `id` int(11) NOT NULL,
  `title` varchar(120) NOT NULL,
  `desctiption` varchar(256) NOT NULL,
  `imageName` varchar(256) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  `createDate` datetime NOT NULL,
  `editDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- RELATIONS FOR TABLE `tbl_slider`:
--

--
-- Dumping data for table `tbl_slider`
--

INSERT INTO `tbl_slider` (`id`, `title`, `desctiption`, `imageName`, `status`, `createDate`, `editDate`) VALUES
(2, 'second slider', 'second slidhlekji', 'slider_pic_ecmy2015-earlybirdpeople-tobeusedinsept_1024.jpg', 1, '2015-09-22 14:09:45', '2015-09-22 06:09:45'),
(3, 'secodn', 'second ehlon', 'slider_pic_ehlon.jpg', 1, '2015-09-22 14:41:47', '2015-09-22 06:41:47'),
(4, '3rd slider', 'here for 3rd slider', 'slider_pic_fb-bg.jpg', 1, '2015-09-22 15:30:11', '2015-09-22 07:30:11'),
(5, '4th slider', '4th slider here', 'slider_pic_Chrysanthemum.jpg', 1, '2015-09-22 15:54:33', '2015-09-22 07:54:33'),
(6, '5th slider', '5th slider here', 'slider_pic_Tulips.jpg', 1, '2015-09-22 15:54:44', '2015-09-22 07:54:44'),
(7, '6th slider', '6th slider here', 'slider_pic_Jellyfish.jpg', 1, '2015-09-22 15:54:53', '2015-09-22 07:54:53'),
(8, '7th slider', '7th slider here', 'slider_pic_Koala.jpg', 1, '2015-09-22 15:55:02', '2015-09-22 07:55:02'),
(9, '8th slider', '8th slider here', 'slider_pic_Desert.jpg', 1, '2015-09-22 15:55:12', '2015-09-22 07:55:12');

-- --------------------------------------------------------

--
-- Table structure for table `tse_ext_languages`
--
-- Creation: Sep 21, 2015 at 01:45 AM
--

CREATE TABLE IF NOT EXISTS `tse_ext_languages` (
  `id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nativeName` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code2` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code3` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `flagLink` text COLLATE utf8_unicode_ci,
  `status` tinyint(1) DEFAULT '1',
  `ordering` int(11) DEFAULT NULL,
  `createDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `asDefault` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- RELATIONS FOR TABLE `tse_ext_languages`:
--

--
-- Dumping data for table `tse_ext_languages`
--

INSERT INTO `tse_ext_languages` (`id`, `name`, `nativeName`, `code2`, `code3`, `flagLink`, `status`, `ordering`, `createDate`, `asDefault`) VALUES
(1, 'English', 'English', 'en', 'eng', NULL, 1, 1, '2014-06-25 15:14:02', 1),
(2, 'German', 'Deutsch', 'de', 'ger', '', 1, 2, '2015-09-22 10:28:23', 0),
(3, 'Spanish', 'España', 'es', 'spa', NULL, 1, 3, '2015-09-22 10:37:59', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tss_all_countries`
--
-- Creation: Sep 21, 2015 at 01:45 AM
--

CREATE TABLE IF NOT EXISTS `tss_all_countries` (
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `code2` varchar(3) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- RELATIONS FOR TABLE `tss_all_countries`:
--

--
-- Dumping data for table `tss_all_countries`
--

INSERT INTO `tss_all_countries` (`name`, `code2`) VALUES
('Andorra', 'AD'),
('United Arab Emirates', 'AE'),
('Afghanistan', 'AF'),
('Antigua and Barbuda', 'AG'),
('Anguilla', 'AI'),
('Albania', 'AL'),
('Armenia', 'AM'),
('Netherlands Antilles', 'AN'),
('Angola', 'AO'),
('Antarctica', 'AQ'),
('Argentina', 'AR'),
('American Samoa', 'AS'),
('Austria', 'AT'),
('Australia', 'AU'),
('Aruba', 'AW'),
('Åland Islands', 'AX'),
('Azerbaijan', 'AZ'),
('Bosnia and Herzegovina', 'BA'),
('Barbados', 'BB'),
('Bangladesh', 'BD'),
('Belgium', 'BE'),
('Burkina Faso', 'BF'),
('Bulgaria', 'BG'),
('Bahrain', 'BH'),
('Burundi', 'BI'),
('Benin', 'BJ'),
('Saint Barthélemy', 'BL'),
('Bermuda', 'BM'),
('Brunei Darussalam', 'BN'),
('Bolivia', 'BO'),
('Brazil', 'BR'),
('Bahamas', 'BS'),
('Bhutan', 'BT'),
('Bouvet Island', 'BV'),
('Botswana', 'BW'),
('Belarus', 'BY'),
('Belize', 'BZ'),
('Canada', 'CA'),
('Cocos (Keeling) Islands', 'CC'),
('Congo, The Democratic Republic of the', 'CD'),
('Central African Republic', 'CF'),
('Congo', 'CG'),
('Switzerland', 'CH'),
('Côte D''Ivoire', 'CI'),
('Cook Islands', 'CK'),
('Chile', 'CL'),
('Cameroon', 'CM'),
('China', 'CN'),
('Colombia', 'CO'),
('Costa Rica', 'CR'),
('Cuba', 'CU'),
('Cape Verde', 'CV'),
('Christmas Island', 'CX'),
('Cyprus', 'CY'),
('Czech Republic', 'CZ'),
('Germany', 'DE'),
('Djibouti', 'DJ'),
('Denmark', 'DK'),
('Dominica', 'DM'),
('Dominican Republic', 'DO'),
('Algeria', 'DZ'),
('Ecuador', 'EC'),
('Estonia', 'EE'),
('Egypt', 'EG'),
('Western Sahara', 'EH'),
('Eritrea', 'ER'),
('Spain', 'ES'),
('Ethiopia', 'ET'),
('Finland', 'FI'),
('Fiji', 'FJ'),
('Falkland Islands (Malvinas)', 'FK'),
('Micronesia, Federated States of', 'FM'),
('Faroe Islands', 'FO'),
('France', 'FR'),
('Gabon', 'GA'),
('United Kingdom', 'GB'),
('Grenada', 'GD'),
('Georgia', 'GE'),
('French Guiana', 'GF'),
('Guernsey', 'GG'),
('Ghana', 'GH'),
('Gibraltar', 'GI'),
('Greenland', 'GL'),
('Gambia', 'GM'),
('Guinea', 'GN'),
('Guadeloupe', 'GP'),
('Equatorial Guinea', 'GQ'),
('Greece', 'GR'),
('South Georgia and the South Sandwich Islands', 'GS'),
('Guatemala', 'GT'),
('Guam', 'GU'),
('Guinea-Bissau', 'GW'),
('Guyana', 'GY'),
('Hong Kong', 'HK'),
('Heard Island and McDonald Islands', 'HM'),
('Honduras', 'HN'),
('Croatia', 'HR'),
('Haiti', 'HT'),
('Hungary', 'HU'),
('Indonesia', 'ID'),
('Ireland', 'IE'),
('Israel', 'IL'),
('Isle of Man', 'IM'),
('India', 'IN'),
('British Indian Ocean Territory', 'IO'),
('Iraq', 'IQ'),
('Iran, Islamic Republic of', 'IR'),
('Iceland', 'IS'),
('Italy', 'IT'),
('Jersey', 'JE'),
('Jamaica', 'JM'),
('Jordan', 'JO'),
('Japan', 'JP'),
('Kenya', 'KE'),
('Kyrgyzstan', 'KG'),
('Cambodia', 'KH'),
('Kiribati', 'KI'),
('Comoros', 'KM'),
('Saint Kitts and Nevis', 'KN'),
('Korea, Democratic People''s Republic of', 'KP'),
('Korea, Republic of', 'KR'),
('Kuwait', 'KW'),
('Cayman Islands', 'KY'),
('Kazakhstan', 'KZ'),
('Lao People''s Democratic Republic', 'LA'),
('Lebanon', 'LB'),
('Saint Lucia', 'LC'),
('Liechtenstein', 'LI'),
('Sri Lanka', 'LK'),
('Liberia', 'LR'),
('Lesotho', 'LS'),
('Lithuania', 'LT'),
('Luxembourg', 'LU'),
('Latvia', 'LV'),
('Libyan Arab Jamahiriya', 'LY'),
('Morocco', 'MA'),
('Monaco', 'MC'),
('Moldova, Republic of', 'MD'),
('Montenegro', 'ME'),
('Saint Martin', 'MF'),
('Madagascar', 'MG'),
('Marshall Islands', 'MH'),
('Macedonia, The Former Yugoslav Republic of', 'MK'),
('Mali', 'ML'),
('Myanmar', 'MM'),
('Mongolia', 'MN'),
('Macao', 'MO'),
('Northern Mariana Islands', 'MP'),
('Martinique', 'MQ'),
('Mauritania', 'MR'),
('Montserrat', 'MS'),
('Malta', 'MT'),
('Mauritius', 'MU'),
('Maldives', 'MV'),
('Malawi', 'MW'),
('Mexico', 'MX'),
('Malaysia', 'MY'),
('Mozambique', 'MZ'),
('Namibia', 'NA'),
('New Caledonia', 'NC'),
('Niger', 'NE'),
('Norfolk Island', 'NF'),
('Nigeria', 'NG'),
('Nicaragua', 'NI'),
('Netherlands', 'NL'),
('Norway', 'NO'),
('Nepal', 'NP'),
('Nauru', 'NR'),
('Niue', 'NU'),
('New Zealand', 'NZ'),
('Oman', 'OM'),
('Panama', 'PA'),
('Peru', 'PE'),
('French Polynesia', 'PF'),
('Papua New Guinea', 'PG'),
('Philippines', 'PH'),
('Pakistan', 'PK'),
('Poland', 'PL'),
('Saint Pierre and Miquelon', 'PM'),
('Pitcairn', 'PN'),
('Puerto Rico', 'PR'),
('Palestinian Territory, Occupied', 'PS'),
('Portugal', 'PT'),
('Palau', 'PW'),
('Paraguay', 'PY'),
('Qatar', 'QA'),
('Reunion', 'RE'),
('Romania', 'RO'),
('Serbia', 'RS'),
('Russian Federation', 'RU'),
('Rwanda', 'RW'),
('Saudi Arabia', 'SA'),
('Solomon Islands', 'SB'),
('Seychelles', 'SC'),
('Sudan', 'SD'),
('Sweden', 'SE'),
('Singapore', 'SG'),
('Saint Helena', 'SH'),
('Slovenia', 'SI'),
('Svalbard and Jan Mayen', 'SJ'),
('Slovakia', 'SK'),
('Sierra Leone', 'SL'),
('San Marino', 'SM'),
('Senegal', 'SN'),
('Somalia', 'SO'),
('Suriname', 'SR'),
('Sao Tome and Principe', 'ST'),
('El Salvador', 'SV'),
('Syrian Arab Republic', 'SY'),
('Swaziland', 'SZ'),
('Turks and Caicos Islands', 'TC'),
('Chad', 'TD'),
('French Southern Territories', 'TF'),
('Togo', 'TG'),
('Thailand', 'TH'),
('Tajikistan', 'TJ'),
('Tokelau', 'TK'),
('Timor-Leste', 'TL'),
('Turkmenistan', 'TM'),
('Tunisia', 'TN'),
('Tonga', 'TO'),
('Turkey', 'TR'),
('Trinidad and Tobago', 'TT'),
('Tuvalu', 'TV'),
('Taiwan, Province Of China', 'TW'),
('Tanzania, United Republic of', 'TZ'),
('Ukraine', 'UA'),
('Uganda', 'UG'),
('United States Minor Outlying Islands', 'UM'),
('United States', 'US'),
('Uruguay', 'UY'),
('Uzbekistan', 'UZ'),
('Holy See (Vatican City State)', 'VA'),
('Saint Vincent and the Grenadines', 'VC'),
('Venezuela', 'VE'),
('Virgin Islands, British', 'VG'),
('Virgin Islands, U.S.', 'VI'),
('Viet Nam', 'VN'),
('Vanuatu', 'VU'),
('Wallis And Futuna', 'WF'),
('Samoa', 'WS'),
('Yemen', 'YE'),
('Mayotte', 'YT'),
('South Africa', 'ZA'),
('Zambia', 'ZM'),
('Zimbabwe', 'ZW'),
('Andorra', 'AD'),
('United Arab Emirates', 'AE'),
('Afghanistan', 'AF'),
('Antigua and Barbuda', 'AG'),
('Anguilla', 'AI'),
('Albania', 'AL'),
('Armenia', 'AM'),
('Netherlands Antilles', 'AN'),
('Angola', 'AO'),
('Antarctica', 'AQ'),
('Argentina', 'AR'),
('American Samoa', 'AS'),
('Austria', 'AT'),
('Australia', 'AU'),
('Aruba', 'AW'),
('Åland Islands', 'AX'),
('Azerbaijan', 'AZ'),
('Bosnia and Herzegovina', 'BA'),
('Barbados', 'BB'),
('Bangladesh', 'BD'),
('Belgium', 'BE'),
('Burkina Faso', 'BF'),
('Bulgaria', 'BG'),
('Bahrain', 'BH'),
('Burundi', 'BI'),
('Benin', 'BJ'),
('Saint Barthélemy', 'BL'),
('Bermuda', 'BM'),
('Brunei Darussalam', 'BN'),
('Bolivia', 'BO'),
('Brazil', 'BR'),
('Bahamas', 'BS'),
('Bhutan', 'BT'),
('Bouvet Island', 'BV'),
('Botswana', 'BW'),
('Belarus', 'BY'),
('Belize', 'BZ'),
('Canada', 'CA'),
('Cocos (Keeling) Islands', 'CC'),
('Congo, The Democratic Republic of the', 'CD'),
('Central African Republic', 'CF'),
('Congo', 'CG'),
('Switzerland', 'CH'),
('Côte D''Ivoire', 'CI'),
('Cook Islands', 'CK'),
('Chile', 'CL'),
('Cameroon', 'CM'),
('China', 'CN'),
('Colombia', 'CO'),
('Costa Rica', 'CR'),
('Cuba', 'CU'),
('Cape Verde', 'CV'),
('Christmas Island', 'CX'),
('Cyprus', 'CY'),
('Czech Republic', 'CZ'),
('Germany', 'DE'),
('Djibouti', 'DJ'),
('Denmark', 'DK'),
('Dominica', 'DM'),
('Dominican Republic', 'DO'),
('Algeria', 'DZ'),
('Ecuador', 'EC'),
('Estonia', 'EE'),
('Egypt', 'EG'),
('Western Sahara', 'EH'),
('Eritrea', 'ER'),
('Spain', 'ES'),
('Ethiopia', 'ET'),
('Finland', 'FI'),
('Fiji', 'FJ'),
('Falkland Islands (Malvinas)', 'FK'),
('Micronesia, Federated States of', 'FM'),
('Faroe Islands', 'FO'),
('France', 'FR'),
('Gabon', 'GA'),
('United Kingdom', 'GB'),
('Grenada', 'GD'),
('Georgia', 'GE'),
('French Guiana', 'GF'),
('Guernsey', 'GG'),
('Ghana', 'GH'),
('Gibraltar', 'GI'),
('Greenland', 'GL'),
('Gambia', 'GM'),
('Guinea', 'GN'),
('Guadeloupe', 'GP'),
('Equatorial Guinea', 'GQ'),
('Greece', 'GR'),
('South Georgia and the South Sandwich Islands', 'GS'),
('Guatemala', 'GT'),
('Guam', 'GU'),
('Guinea-Bissau', 'GW'),
('Guyana', 'GY'),
('Hong Kong', 'HK'),
('Heard Island and McDonald Islands', 'HM'),
('Honduras', 'HN'),
('Croatia', 'HR'),
('Haiti', 'HT'),
('Hungary', 'HU'),
('Indonesia', 'ID'),
('Ireland', 'IE'),
('Israel', 'IL'),
('Isle of Man', 'IM'),
('India', 'IN'),
('British Indian Ocean Territory', 'IO'),
('Iraq', 'IQ'),
('Iran, Islamic Republic of', 'IR'),
('Iceland', 'IS'),
('Italy', 'IT'),
('Jersey', 'JE'),
('Jamaica', 'JM'),
('Jordan', 'JO'),
('Japan', 'JP'),
('Kenya', 'KE'),
('Kyrgyzstan', 'KG'),
('Cambodia', 'KH'),
('Kiribati', 'KI'),
('Comoros', 'KM'),
('Saint Kitts and Nevis', 'KN'),
('Korea, Democratic People''s Republic of', 'KP'),
('Korea, Republic of', 'KR'),
('Kuwait', 'KW'),
('Cayman Islands', 'KY'),
('Kazakhstan', 'KZ'),
('Lao People''s Democratic Republic', 'LA'),
('Lebanon', 'LB'),
('Saint Lucia', 'LC'),
('Liechtenstein', 'LI'),
('Sri Lanka', 'LK'),
('Liberia', 'LR'),
('Lesotho', 'LS'),
('Lithuania', 'LT'),
('Luxembourg', 'LU'),
('Latvia', 'LV'),
('Libyan Arab Jamahiriya', 'LY'),
('Morocco', 'MA'),
('Monaco', 'MC'),
('Moldova, Republic of', 'MD'),
('Montenegro', 'ME'),
('Saint Martin', 'MF'),
('Madagascar', 'MG'),
('Marshall Islands', 'MH'),
('Macedonia, The Former Yugoslav Republic of', 'MK'),
('Mali', 'ML'),
('Myanmar', 'MM'),
('Mongolia', 'MN'),
('Macao', 'MO'),
('Northern Mariana Islands', 'MP'),
('Martinique', 'MQ'),
('Mauritania', 'MR'),
('Montserrat', 'MS'),
('Malta', 'MT'),
('Mauritius', 'MU'),
('Maldives', 'MV'),
('Malawi', 'MW'),
('Mexico', 'MX'),
('Malaysia', 'MY'),
('Mozambique', 'MZ'),
('Namibia', 'NA'),
('New Caledonia', 'NC'),
('Niger', 'NE'),
('Norfolk Island', 'NF'),
('Nigeria', 'NG'),
('Nicaragua', 'NI'),
('Netherlands', 'NL'),
('Norway', 'NO'),
('Nepal', 'NP'),
('Nauru', 'NR'),
('Niue', 'NU'),
('New Zealand', 'NZ'),
('Oman', 'OM'),
('Panama', 'PA'),
('Peru', 'PE'),
('French Polynesia', 'PF'),
('Papua New Guinea', 'PG'),
('Philippines', 'PH'),
('Pakistan', 'PK'),
('Poland', 'PL'),
('Saint Pierre and Miquelon', 'PM'),
('Pitcairn', 'PN'),
('Puerto Rico', 'PR'),
('Palestinian Territory, Occupied', 'PS'),
('Portugal', 'PT'),
('Palau', 'PW'),
('Paraguay', 'PY'),
('Qatar', 'QA'),
('Reunion', 'RE'),
('Romania', 'RO'),
('Serbia', 'RS'),
('Russian Federation', 'RU'),
('Rwanda', 'RW'),
('Saudi Arabia', 'SA'),
('Solomon Islands', 'SB'),
('Seychelles', 'SC'),
('Sudan', 'SD'),
('Sweden', 'SE'),
('Singapore', 'SG'),
('Saint Helena', 'SH'),
('Slovenia', 'SI'),
('Svalbard and Jan Mayen', 'SJ'),
('Slovakia', 'SK'),
('Sierra Leone', 'SL'),
('San Marino', 'SM'),
('Senegal', 'SN'),
('Somalia', 'SO'),
('Suriname', 'SR'),
('Sao Tome and Principe', 'ST'),
('El Salvador', 'SV'),
('Syrian Arab Republic', 'SY'),
('Swaziland', 'SZ'),
('Turks and Caicos Islands', 'TC'),
('Chad', 'TD'),
('French Southern Territories', 'TF'),
('Togo', 'TG'),
('Thailand', 'TH'),
('Tajikistan', 'TJ'),
('Tokelau', 'TK'),
('Timor-Leste', 'TL'),
('Turkmenistan', 'TM'),
('Tunisia', 'TN'),
('Tonga', 'TO'),
('Turkey', 'TR'),
('Trinidad and Tobago', 'TT'),
('Tuvalu', 'TV'),
('Taiwan, Province Of China', 'TW'),
('Tanzania, United Republic of', 'TZ'),
('Ukraine', 'UA'),
('Uganda', 'UG'),
('United States Minor Outlying Islands', 'UM'),
('United States', 'US'),
('Uruguay', 'UY'),
('Uzbekistan', 'UZ'),
('Holy See (Vatican City State)', 'VA'),
('Saint Vincent and the Grenadines', 'VC'),
('Venezuela', 'VE'),
('Virgin Islands, British', 'VG'),
('Virgin Islands, U.S.', 'VI'),
('Viet Nam', 'VN'),
('Vanuatu', 'VU'),
('Wallis And Futuna', 'WF'),
('Samoa', 'WS'),
('Yemen', 'YE'),
('Mayotte', 'YT'),
('South Africa', 'ZA'),
('Zambia', 'ZM'),
('Zimbabwe', 'ZW');

-- --------------------------------------------------------

--
-- Table structure for table `tss_all_languages`
--
-- Creation: Sep 21, 2015 at 01:45 AM
--

CREATE TABLE IF NOT EXISTS `tss_all_languages` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `nativeName` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code2` varchar(3) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=169 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- RELATIONS FOR TABLE `tss_all_languages`:
--

--
-- Dumping data for table `tss_all_languages`
--

INSERT INTO `tss_all_languages` (`id`, `name`, `nativeName`, `code2`) VALUES
(1, 'Abkhazian', 'Аҧсуа', 'ab'),
(2, 'Afar', 'Afaraf', 'aa'),
(3, 'Afrikaans', 'Afrikaans', 'af'),
(4, 'Akan', 'Akan', 'ak'),
(5, 'Albanian', 'Shqip', 'sq'),
(6, 'Amharic', 'አማርኛ', 'am'),
(7, 'Arabic', 'العربية', 'ar'),
(8, 'Aragonese', 'Aragonés', 'an'),
(9, 'Assamese', 'অসমীয়া', 'as'),
(10, 'Armenian', 'Հայերեն', 'hy'),
(11, 'Avaric', 'авар мацӀ', 'av'),
(12, 'Avestan', 'avesta', 'ae'),
(13, 'Aymara', 'aymar aru', 'ay'),
(14, 'Azerbaijani', 'azərbaycan dili', 'az'),
(15, 'Bashkir', 'башҡорт теле', 'ba'),
(16, 'Bambara', 'bamanankan', 'bm'),
(17, 'Basque', 'euskara', 'eu'),
(18, 'Belarusian', 'Беларуская', 'be'),
(19, 'Bengali', 'বাংলা', 'bn'),
(20, 'Bihari', 'भोजपुरी', 'bh'),
(21, 'Bislama', 'Bislama', 'bi'),
(22, 'Bosnian', 'bosanski jezik', 'bs'),
(23, 'Breton', 'brezhoneg', 'br'),
(24, 'Bulgarian', 'български език', 'bg'),
(25, 'Burmese', 'ဗမာစာ', 'my'),
(26, 'Catalan; Valencian', 'Català', 'ca'),
(27, 'Chamorro', 'Chamoru', 'ch'),
(28, 'Chechen', 'нохчийн мотт', 'ce'),
(29, 'Chichewa', 'chinyanja', 'ny'),
(30, 'Chinese', '"中文 (Zhōngwén), 汉语, 漢語"', 'zh'),
(31, 'Chuvash', 'чӑваш чӗлхи', 'cv'),
(32, 'Cornish', 'Kernewek', 'kw'),
(33, 'Corsican', 'corsu', 'co'),
(34, 'Cree', 'ᓀᐦᐃᔭᐍᐏᐣ', 'cr'),
(35, 'Croatian', 'hrvatski', 'hr'),
(36, 'Czech', 'česky', 'cs'),
(37, 'Danish', 'dansk', 'da'),
(38, 'Maldivian', 'ދިވެހި', 'dv'),
(39, 'Dzongkha', 'རྫོང་ཁ', 'dz'),
(40, 'English', 'English', 'en'),
(41, 'Esperanto', 'Esperanto', 'eo'),
(42, 'Estonian', 'eesti', 'et'),
(43, 'Ewe', 'Eʋegbe', 'ee'),
(44, 'Faroese', 'føroyskt', 'fo'),
(45, 'Fijian', 'vosa Vakaviti', 'fj'),
(46, 'Finnish', 'suomi', 'fi'),
(47, 'French', 'français', 'fr'),
(48, 'Fula', 'Pular', 'ff'),
(49, 'Galician', 'Galego', 'gl'),
(50, 'German', 'Deutsch', 'de'),
(51, 'Greek', 'Ελληνικά', 'el'),
(52, 'Guaraní', 'Avañe''ẽ', 'gn'),
(53, 'Gujarati', 'ગુજરાતી', 'gu'),
(54, 'Haitian', 'Kreyòl ayisyen', 'ht'),
(55, 'Hausa', '"Hausa, هَوُسَ"', 'ha'),
(56, 'Hebrew', 'עברית', 'he'),
(57, 'Herero', 'Otjiherero', 'hz'),
(58, 'Hindi', 'हिन्दी, हिंदी"', 'hi'),
(59, 'Hiri Motu', 'Hiri Motu', 'ho'),
(60, 'Hungarian', 'Magyar', 'hu'),
(61, 'Indonesian', 'Bahasa Indonesia', 'id'),
(62, 'Irish', 'Gaeilge', 'ga'),
(63, 'Igbo', 'Igbo', 'ig'),
(64, 'Inupiaq', 'Iñupiaq', 'ik'),
(65, 'Ido', 'Ido', 'io'),
(66, 'Icelandic', 'Íslenska', 'is'),
(67, 'Italian', 'Italiano', 'it'),
(68, 'Inuktitut', 'ᐃᓄᒃᑎᑐᑦ', 'iu'),
(69, 'Japanese', '日本語', 'ja'),
(70, 'Javanese', 'basa Jawa', 'jv'),
(71, 'Georgian', 'ქართული', 'ka'),
(72, 'Kongo', 'KiKongo', 'kg'),
(73, 'Kazakh', 'Қазақ тілі', 'kk'),
(74, 'Central Khmer', 'ភាសាខ្មែរ', 'km'),
(75, 'Kannada', 'ಕನ್ನಡ', 'kn'),
(76, 'Korean', '韓國語', 'ko'),
(77, 'Kanuri', 'Kanuri', 'kr'),
(78, 'Kashmiri', '"कश्मीरी, كشميري‎"', 'ks'),
(79, 'Kurdish', 'Kurdî', 'ku'),
(80, 'Komi', 'коми кыв', 'kv'),
(81, 'Kirghiz', 'кыргыз тили', 'ky'),
(82, 'Latin', 'latine', 'la'),
(83, 'Luxembourgish', 'Lëtzebuergesch', 'lb'),
(84, 'Luganda', 'Luganda', 'lg'),
(85, 'Lingala', 'Lingála', 'ln'),
(86, 'Lao', 'ພາສາລາວ', 'lo'),
(87, 'Lithuanian', 'lietuvių kalba', 'lt'),
(88, 'Luba-Katanga', '', 'lu'),
(89, 'Latvian', 'latviešu valoda', 'lv'),
(90, 'Malagasy', 'Malagasy fiteny', 'mg'),
(91, 'Marshallese', 'Kajin M̧ajeļ', 'mh'),
(92, 'Manx', '"Gaelg, Gailck"', 'gv'),
(93, 'Māori', 'te reo Māori', 'mi'),
(94, 'Macedonian', 'македонски јазик', 'mk'),
(95, 'Malayalam', 'മലയാളം', 'ml'),
(96, 'Mongolian', 'Монгол', 'mn'),
(97, 'Marathi', 'मराठी', 'mr'),
(98, 'Malay', '"bahasa Melayu, بهاس ملايو‎"', 'ms'),
(99, 'Maltese', 'Malti', 'mt'),
(100, 'Nauru', 'Ekakairũ Naoero', 'na'),
(101, 'North Ndebele', 'isiNdebele', 'nd'),
(102, 'Nepali', 'नेपाली', 'ne'),
(103, 'Ndonga', 'Owambo', 'ng'),
(104, 'Dutch', 'Nederlands', 'nl'),
(105, 'Norwegian', 'Norsk', 'no'),
(106, 'South Ndebele', 'isiNdebele', 'nr'),
(107, 'Navajo', 'Diné bizaad', 'nv'),
(108, 'Oromo', 'Afaan Oromoo', 'om'),
(109, 'Oriya', 'ଓଡ଼ିଆ', 'or'),
(110, 'Ossetian', 'Ирон æвзаг', 'os'),
(111, 'Punjabi', '"ਪੰਜਾਬੀ', 'pa'),
(112, 'Pāli', 'पाऴि', 'pi'),
(113, 'Persian', 'فارسی', 'fa'),
(114, 'Polish', 'polski', 'pl'),
(115, 'Portuguese', 'Português', 'pt'),
(116, 'Quechua', 'Kichwa', 'qu'),
(117, 'Kirundi', 'Rundi', 'rn'),
(118, 'Romanian', 'română', 'ro'),
(119, 'Russian', 'Русский язык', 'ru'),
(120, 'Kinyarwanda', 'Ikinyarwanda', 'rw'),
(121, 'Sanskrit', 'संस्कृतम्', 'sa'),
(122, 'Sardinian', 'sardu', 'sc'),
(123, 'Sindhi', '"सिन्धी, سنڌي، سندھی‎"', 'sd'),
(124, 'Northern Sami', 'Davvisámegiella', 'se'),
(125, 'Samoan', 'gagana fa''a Samoa', 'sm'),
(126, 'Sango', 'yângâ tî sängö', 'sg'),
(127, 'Serbian', 'српски језик', 'sr'),
(128, 'Gaelic', 'Gàidhlig', 'gd'),
(129, 'Shona', 'chiShona', 'sn'),
(130, 'Sinhala', 'සිංහල', 'si'),
(131, 'Slovak', 'slovenčina', 'sk'),
(132, 'Slovene', 'slovenščina', 'sl'),
(133, 'Somali', 'Soomaaliga', 'so'),
(134, 'Southern Sotho', 'Sesotho', 'st'),
(135, 'Sundanese', 'Basa Sunda', 'su'),
(136, 'Swahili', 'Kiswahili', 'sw'),
(137, 'Swati', 'SiSwati', 'ss'),
(138, 'Swedish', 'svenska', 'sv'),
(139, 'Tamil', 'தமிழ்', 'ta'),
(140, 'Telugu', 'తెలుగు', 'te'),
(141, 'Tajik', 'toğikī', 'tg'),
(142, 'Thai', 'ไทย', 'th'),
(143, 'Tigrinya', 'ትግርኛ', 'ti'),
(144, 'Tibetan', 'བོད་ཡིག', 'bo'),
(145, 'Turkmen', 'Türkmen', 'tk'),
(146, 'Tagalog', 'Wikang Tagalog', 'tl'),
(147, 'Tswana', 'Setswana', 'tn'),
(148, 'Tonga', 'faka Tonga', 'to'),
(149, 'Turkish', 'Türkçe', 'tr'),
(150, 'Tsonga', 'Xitsonga', 'ts'),
(151, 'Tatar', 'tatarça', 'tt'),
(152, 'Twi', 'Twi', 'tw'),
(153, 'Tahitian', 'Reo Mā`ohi', 'ty'),
(154, 'Uighur', 'Uyƣurqə', 'ug'),
(155, 'Ukrainian', 'Українська', 'uk'),
(156, 'Urdu', 'اردو', 'ur'),
(157, 'Uzbek', 'O''zbek', 'uz'),
(158, 'Venda', 'Tshivenḓa', 've'),
(159, 'Vietnamese', 'Tiếng Việt', 'vi'),
(160, 'Volapük', 'Volapük', 'vo'),
(161, 'Walloon', 'Walon', 'wa'),
(162, 'Welsh', 'Cymraeg', 'cy'),
(163, 'Wolof', 'Wollof', 'wo'),
(164, 'Xhosa', 'isiXhosa', 'xh'),
(165, 'Yoruba', 'Yorùbá', 'yo'),
(166, 'Zhuang', 'Saw cuengh', 'za'),
(167, 'Zulu', 'isiZulu', 'zu'),
(168, 'Spanish', 'espana', 'es');

-- --------------------------------------------------------

--
-- Table structure for table `tsy_source_messages`
--
-- Creation: Sep 21, 2015 at 01:45 AM
--

CREATE TABLE IF NOT EXISTS `tsy_source_messages` (
  `id` int(11) NOT NULL,
  `category` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- RELATIONS FOR TABLE `tsy_source_messages`:
--

--
-- Dumping data for table `tsy_source_messages`
--

INSERT INTO `tsy_source_messages` (`id`, `category`, `message`) VALUES
(1, 'security', 'Global {global} array cleaned using {method} method.'),
(2, 'labels', 'Username or e-mail'),
(3, 'labels', 'Remember me next time');

-- --------------------------------------------------------

--
-- Table structure for table `tsy_translated_messages`
--
-- Creation: Sep 21, 2015 at 01:45 AM
--

CREATE TABLE IF NOT EXISTS `tsy_translated_messages` (
  `id` int(11) NOT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `translation` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- RELATIONS FOR TABLE `tsy_translated_messages`:
--   `id`
--       `tsy_source_messages` -> `id`
--

--
-- Dumping data for table `tsy_translated_messages`
--

INSERT INTO `tsy_translated_messages` (`id`, `language`, `translation`) VALUES
(1, 'de', 'Global {global} array cleaned using {method} method.'),
(1, 'es', 'Global {global} array cleaned using {method} method.'),
(2, 'de', 'Username or e-mail'),
(3, 'de', 'Remember me next time');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--
-- Creation: Sep 21, 2015 at 01:05 AM
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL,
  `username` varchar(45) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `status` smallint(6) NOT NULL DEFAULT '0',
  `password` varchar(255) DEFAULT NULL,
  `password_strategy` varchar(50) DEFAULT NULL,
  `salt` varchar(255) DEFAULT NULL,
  `requires_new_password` tinyint(1) DEFAULT NULL,
  `reset_token` varchar(255) DEFAULT NULL,
  `login_attempts` int(11) DEFAULT NULL,
  `login_time` int(11) DEFAULT NULL,
  `login_ip` varchar(32) DEFAULT NULL,
  `activation_key` varchar(128) DEFAULT NULL,
  `validation_key` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- RELATIONS FOR TABLE `user`:
--

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `email`, `status`, `password`, `password_strategy`, `salt`, `requires_new_password`, `reset_token`, `login_attempts`, `login_time`, `login_ip`, `activation_key`, `validation_key`, `create_time`, `update_time`) VALUES
(1, 'admin', 'tamilnilo@gmail.com', 1, '723785e83931dd4bbcfecb5ee672262e268bd629', 'ahash', 'e1b22e5b4e1b9503f2c9bc469068106327694b70', NULL, NULL, NULL, 15, '::1', NULL, '8ccff83071317432872cc5e093d56bbe', '2012-11-18 14:26:59', '2012-11-18 14:26:59');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_articles`
--
ALTER TABLE `tbl_articles`
  ADD PRIMARY KEY (`id`), ADD KEY `title` (`title`), ADD FULLTEXT KEY `description` (`description`);

--
-- Indexes for table `tbl_menu`
--
ALTER TABLE `tbl_menu`
  ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `title` (`Title`), ADD UNIQUE KEY `shortText` (`shortText`);

--
-- Indexes for table `tbl_page`
--
ALTER TABLE `tbl_page`
  ADD PRIMARY KEY (`id`), ADD KEY `title` (`title`), ADD FULLTEXT KEY `description` (`description`);

--
-- Indexes for table `tbl_settings`
--
ALTER TABLE `tbl_settings`
  ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `param` (`param`);

--
-- Indexes for table `tbl_slider`
--
ALTER TABLE `tbl_slider`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tse_ext_languages`
--
ALTER TABLE `tse_ext_languages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tss_all_languages`
--
ALTER TABLE `tss_all_languages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tsy_source_messages`
--
ALTER TABLE `tsy_source_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tsy_translated_messages`
--
ALTER TABLE `tsy_translated_messages`
  ADD PRIMARY KEY (`id`,`language`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `email` (`email`), ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_articles`
--
ALTER TABLE `tbl_articles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `tbl_menu`
--
ALTER TABLE `tbl_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `tbl_page`
--
ALTER TABLE `tbl_page`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `tbl_settings`
--
ALTER TABLE `tbl_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tbl_slider`
--
ALTER TABLE `tbl_slider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `tse_ext_languages`
--
ALTER TABLE `tse_ext_languages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tss_all_languages`
--
ALTER TABLE `tss_all_languages`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=169;
--
-- AUTO_INCREMENT for table `tsy_source_messages`
--
ALTER TABLE `tsy_source_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `tsy_translated_messages`
--
ALTER TABLE `tsy_translated_messages`
ADD CONSTRAINT `fk_translated_source` FOREIGN KEY (`id`) REFERENCES `tsy_source_messages` (`id`) ON DELETE CASCADE;
SET FOREIGN_KEY_CHECKS=1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
